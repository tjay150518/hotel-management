import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { SharedModule } from '../../shared/shared.module';
import { SalesService } from '../../services/sales.service';
import { WordToPdfService } from '../../services/word-to-pdf.service';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import Docxtemplater from 'docxtemplater';
import PizZip from 'pizzip';
import JSZip from 'JSZip';
import { saveAs } from 'file-saver';
import { Router } from '@angular/router';
@Component({
  selector: 'app-invoice',
  standalone: true,
  imports: [SharedModule],
  templateUrl: './invoice.component.html',
  styleUrl: './invoice.component.scss'
})
export class InvoiceComponent implements OnInit {
  dataSource = new MatTableDataSource<any>([]);
  originalDataSource: any = [];
  // displayedColumns: string[] = ['sno', 'nameOfTheDivision', 'schemeCode', 'schemeName', 'schemeType', 'unitType', 'totalUnit', 'allottedUnits', 'unsoldUnits', 'projectStatus', 'publishedStatus', 'action', 'websiteData', 'masterData'];
  displayedColumns: string[] = ['sno', 'name', 'address', 'cgst', 'sgst', 'subtotal', 'totalamount', 'action'];
  loader: boolean = false;
  constructor(private salesService: SalesService, private wordService: WordToPdfService,
    private router: Router
  ) {

  }
  ngOnInit() {

    this.getAllInvoiceData();

  }
  getAllInvoiceData() {
    this.salesService.dtpGetInvoiceData().subscribe((res: any) => {
      if (res) {
        this.dataSource.data = res;
      }
    })
  }

  downloadWord(data: any) {
    // debugger
    const docxUrl = '../../../../assets/Invoice_dtp.docx';

    // let docData = [
    // //   {
    // //     address: 'chennai',
    // //     gst: 12333333
    // //   }, {
    // //     address: data.address,
    // //     gst: data.gst
    // //   },
    // // ]

    let docData = this.dataSource.data;
    this.wordService.generateMultiPageDocx(docxUrl, docData, "test.docx");
    // this.wordService.generateDocument(docData, docxUrl);
    // this.wordService.generateDocx(docData, docxUrl, 'invoice.docx')
  }

  // generatePDF() {
  //   const doc = new jsPDF();

  //   // Loop through each invoice to render as a separate page in the PDF
  //   this.invoices.forEach((invoice, index) => {
  //     // Create a temporary element for the invoice
  //     const invoiceElement = document.getElementById(`invoice-template-${invoice.invoiceNo}`);

  //     if (invoiceElement) {
  //       // Use html2canvas to convert the HTML into an image
  //       html2canvas(invoiceElement).then((canvas) => {
  //         const imgData = canvas.toDataURL('image/png');

  //         // Add the image to the PDF (new page for each invoice)
  //         if (index > 0) {
  //           doc.addPage();  // Add a new page for each invoice
  //         }

  //         // The image is added at coordinates (0,0), and its size is set to A4 (210x297mm)
  //         doc.addImage(imgData, 'PNG', 0, 0, 210, 297);  // You may need to adjust the size if necessary

  //         // After all invoices are processed, save the PDF
  //         if (index === this.invoices.length - 1) {
  //           doc.save('invoices.pdf');
  //         }
  //       });
  //     }
  //   });
  // }
  invoices = [
    {
      address: 'chennai20494',
      gst: 12333333
    }, {
      address: 'chennai294wfpwoj',
      gst: 123
    },
    {
      address: 'chennai294dfs',
      gst: 123
    },
    {
      address: 'chennai294sfs',
      gst: 123
    },
    {
      address: 'chennai294sfvsfd',
      gst: 123
    },
  ]

  goToEdit(data: any) {
    // debugger
    this.router.navigate(['/DTP/invoice_edit'], { queryParams: { mode: 'view', id: data.id } });

  }
  generateInvoices() {
    this.loader = true;

    // Fetch the template for the docx file (This can be hosted locally or remotely)
    // const templateUrl = '../../../assets/Invoice_dtp2.docx';  // Update with the correct path to your template
    const templateUrl = '../../../assets/Invoice_dtp1.docx';  // Update with the correct path to your template
    // debugger

    fetch(templateUrl)
      .then(response => response.arrayBuffer())
      .then(templateBuffer => {
        const zip = new JSZip();  // Initialize JSZip for zipping the generated files
        const docxPromises: any[] = [];
        // Loop through the invoices and generate a .docx for each
        this.dataSource.data.forEach((invoice: any, index: any) => {
          const doc = new Docxtemplater(new PizZip(templateBuffer), { paragraphLoop: true, linebreaks: true });

          // Prepare data for the placeholder replacement
          let indexData = 30 + index + 1;
          const data = {
            index: indexData,
            address: invoice.address + ' ' + 'TP',
            name: invoice.name,
            district: invoice.district,
            // price: invoice.subInvoice[0].price,
            price: invoice.subInvoice[0].quantity,
            total: invoice.subInvoice[0].total,
            subtotal: invoice.subTotal,
            totalamount: invoice.totalAmount,
            cgst: invoice.cgst,
            sgst: invoice.sgst,
            amountwords: invoice.totalAmountInWords,
            description: invoice.subInvoice[0].description
            // invoiceNo: invoice.invoiceNo,
            // date: invoice.date,
            // to: invoice.to,
            // amount: invoice.amount,
          };

          // Set the data for replacing the placeholders
          doc.setData(data);

          // Generate the document for each invoice
          docxPromises.push(
            new Promise<void>((resolve, reject) => {
              try {
                doc.render();  // Generate the .docx file
                const generatedDoc = doc.getZip().generate({ type: 'blob' });
                this.loader = false;
                zip.file(`${invoice.address}.docx`, generatedDoc);
                resolve();
              } catch (error) {
                reject(error);
              }
            })
          );
        });

        // Once all documents are generated, zip them and allow the user to download
        Promise.all(docxPromises).then(() => {
          zip.generateAsync({ type: 'blob' }).then((content: any) => {
            // Use FileSaver to trigger the download
            saveAs(content, 'invoices.zip');
          });
        });
      })
      .catch(error => {
        console.error('Error generating invoices:', error);
      });
  }

  // generateInvoices() {
  //   const templateUrl = '../../../assets/Invoice_dtp2.docx'; // Path to your template file

  //   fetch(templateUrl)
  //     .then(response => response.arrayBuffer())
  //     .then(templateBuffer => {
  //       const zip = new JSZip(); // Initialize JSZip to zip all documents
  //       const docxPromises: Promise<void>[] = [];

  //       this.invoices.forEach((invoice: any) => {
  //         const doc = new Docxtemplater(new PizZip(templateBuffer), { paragraphLoop: true, linebreaks: true });

  //         // New API for setting the data
  //         const templateData = {
  //           address: invoice.address,
  //           invoiceNo: invoice.invoiceNo,
  //           date: invoice.date,
  //           to: invoice.to,
  //           amount: invoice.amount,
  //           gst: invoice.gst,
  //         };

  //         docxPromises.push(
  //           new Promise<void>((resolve, reject) => {
  //             try {
  //               doc.compile(); // Compile the template (replaces .setData)
  //               doc.render(templateData); // Render with template data (new method)

  //               const generatedDoc = doc.getZip().generate({ type: 'blob' });
  //               zip.file(`${invoice.invoiceNo}.docx`, generatedDoc); // Name the file based on invoice number
  //               resolve();
  //             } catch (error) {
  //               console.error('Error rendering document:', error);
  //               reject(error);
  //             }
  //           })
  //         );
  //       });

  //       // Wait for all documents to be generated and then zip them
  //       Promise.all(docxPromises).then(() => {
  //         zip.generateAsync({ type: 'blob' }).then(content => {
  //           saveAs(content, 'invoices.zip'); // Trigger the download of the zip file
  //         });
  //       });
  //     })
  //     .catch(error => {
  //       console.error('Error fetching template or generating invoices:', error);
  //     });
  // }

}
