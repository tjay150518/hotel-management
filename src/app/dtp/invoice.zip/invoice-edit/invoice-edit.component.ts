import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SalesService } from '../../services/sales.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';

@Component({
  selector: 'app-invoice-edit',
  standalone: true,
  imports: [SharedModule],
  templateUrl: './invoice-edit.component.html',
  styleUrl: './invoice-edit.component.scss'
})
export class InvoiceEditComponent implements OnInit {
  invoiceform!: FormGroup;
  constructor(private route: ActivatedRoute, private salesService: SalesService, private fb: FormBuilder) {

  }
  ngOnInit(): void {

    this.invoiceform = this.fb.group({
      name: ['', [Validators.required,
      ]],
      address: ['', [Validators.required,
      ]],
      price: ['', [Validators.required,
      ]],
      total: ['', [Validators.required,
      ]],

      cgst: ['', [Validators.required,
      ]],
      sgst: ['', [Validators.required,
      ]],

      subtotal: ['', [Validators.required,
      ]],

      totalamount: ['', [Validators.required,
      ]],
      totalamountwords: ['', [Validators.required,]]
    });

    this.route.queryParams.subscribe(params => {
      let id = params['id'];
      console.log('id', id);
      this.getDataByID(id)
    });
  }

  getDataByID(id: any) {
    this.salesService.getDtpDataById(id).subscribe((res: any) => {
      if (res) {
        this.invoiceform.patchValue({
          name: res.name,
          address: res.address,
          price: res.subInvoice[0].quantity,
          total: res.subInvoice[0].total,
          cgst: res.cgst,
          sgst: res.sgst,
          subtotal: res.subTotal,
          totalamount: res.totalAmount,
          totalamountwords: res.totalAmountInWords
        })


      }
    })
  }

}
